{
    "name": "Onestein API Client",
    "category": "Tools",
    "version": "14.0.1.0.0",
    "author": "Onestein",
    "license": "LGPL-3",
    "depends": [
    ],
    "data": [
        "security/ir_model_access.xml",
        "views/onestein_api_config_view.xml",
        "templates/assets.xml",
        "menu.xml"
    ],
    "qweb": [
        "static/src/xml/backend.xml"
    ]
}
