{
    "name": "Vendor Bill OCR",
    "category": "Accounting",
    "version": "14.0.1.0.0",
    "author": "Onestein",
    "license": "LGPL-3",
    "depends": [
        "onestein_api_client",
        "account"
    ],
    "data": [
        "views/account_move.xml",
        "views/res_config_settings.xml"
    ],
}
