{
    'name': 'Profesional Theme',
    'version': '14.0.1.0.1',
    'summary': 'Profesional Theme',
    'author': 'AaitPro',
    'license': 'AGPL-3',
    'maintainer': 'AaitPro',
    'company': 'AaitPro',
    'website': 'https://aaitpro.com',
    'depends': [
        'web'
    ],
    'category':'Branding',
    'description': """
           AaitPro Theme
    """,
   'data': [

    'views/webclient_template_extend.xml',

    ],
    'price':0,
    'currency':'USD',
    'installable': True,
    'auto_install': False,
    'application': True,
    'images': []
}
